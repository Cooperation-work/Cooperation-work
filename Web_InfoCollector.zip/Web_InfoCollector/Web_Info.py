#! /usr/bin/env python
# -*- coding: utf-8 -*-
'''
@File   : Web_Info.py
@Author : DEADF1SH_CAT
@Date   : 2020/11/17 20:49

Description:

Usage:

'''

from core.console import Console

if __name__ == '__main__':
    Console()