from flask import Flask, Response, request, render_template, redirect

import os
import json
import flask_scan

app = Flask(__name__)


@app.route('/', methods=["GET"])
def hello():
    return render_template('index.html')


@app.route('/Scan', methods=["POST"])
def Scan():
    data = request.form.get('data')
    data = json.loads(data)['data']
    url = data['url']
    start = data['start']
    end = data['end']
    pattern = data['pattern']

    try:
        args = flask_scan.flask_Scan(url, pattern, start, end)
        print(args.result)

        return render_template("result.html",result=args.result)

    except Exception as e:
        print(repr(e))

        return render_template("error.html")

@app.route('/test', methods=["GET"])
def test_cms():
    result = flask_scan.flask_Scan("hed9eh0g.top","cms",80,80).test()

    return render_template("result.html",result=result)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
