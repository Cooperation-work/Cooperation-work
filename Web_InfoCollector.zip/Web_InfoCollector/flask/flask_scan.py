

import os
import sys

sys.path.append(os.getcwd().replace("flask", ""))


from plugins.PortScanner import *
from plugins.WebFinger import *
from plugins.Whois_Scan import *
from plugins.CDN_WAF_Finger import *
from plugins.C_Scanner import *
from plugins.Subdomain import *


class flask_Scan():

    def __init__(self, url, pattern, start, end):
        self.result = []
        self.url = url
        self.host = socket.gethostbyname(url)
        self.pattern = pattern
        self.port_list = []
        self.start = int(start)
        self.end = int(end)

        if self.pattern == "Port" or self.pattern == "All":
            self.result.append("\nPort Scan result:\n")
            PScan = PortScanner(self.url, self.start, self.end, 1)
            if PScan.threading():
                self.port_list = PScan.result
                self.port_list.sort()
                # self.result.append(''.join(PScan.result))
            for port in self.port_list:
                self.result.append("[+]Host:" + self.host + " is opening " + str(port) + "\n")

        if self.pattern == "CMS" or self.pattern == "All":
            self.result.append("\nWebFinger Matching Result:\n")
            PScan = PortScanner(self.url, self.start, self.end, 1)
            if PScan.threading():
                self.port_list = PScan.result
                self.port_list.sort()

            for i in self.port_list:
                host = self.url + ":" + str(i)
                print(host)
                try:
                    WFinger = WebFinger(host, 1)
                    if WFinger.threading():
                        self.result.append("[+] " + WFinger.host + " \nuse:\n")
                        result = ""
                        for j in WFinger.result:
                            result += j + "  "
                        self.result.append("[+] fofa_banner: " + result + "\n")
                except Exception as e:
                    raise (e)

        if self.pattern == "CDN_Waf" or self.pattern == "All":
            self.result.append("\nCDN/WAF Finger Matching:\n")
            PScan = PortScanner(self.url, self.start, self.end, 1)
            if PScan.threading():
                self.port_list = PScan.result
                self.port_list.sort()

            for i in self.port_list:
                host = self.url + ":" + str(i)
                try:
                    CWFinger = CDN_WAF_Finger(host)
                    CWFinger.useCDN_WAF()
                    if len(CWFinger.result) != 0:
                        self.result.append("[+] " + host + "\nuse:\n")
                        result = ""
                        for j in CWFinger.result:
                            result += j + "  "
                        self.result.append("[+] CDN/WAF: " + result + "\n")
                except Exception as e:
                    raise (e)

        if self.pattern == "Sub_Domain" or self.pattern == "All":
            self.result.append("\nSub_Domain List:\n")
            try:
                SubScan = Subdomain(self.url, 1)
                if SubScan.threading():
                    for data in SubScan.result:
                        self.result.append("[+] " + data + "\n")
            except Exception as e:
                raise (e)

        if self.pattern == "Whois" or self.pattern == "All":
            self.result.append("\nWhois Scan:\n")
            print("[+]target: " + self.url)
            WScan = Whois_Scan(self.url)
            result = WScan.IP_rdap()
            self.result.append("[+]asn: AS" + result["asn"] + "\n")
            self.result.append("[+]asn_cidr: " + result["asn_cidr"] + "\n")
            self.result.append("[+]asn_registry: " + result["asn_registry"] + "\n")
            self.result.append("[+]asn_country_code: " + result["asn_country_code"] + "\n")
            self.result.append("[+]asn_description: " + result["asn_description"] + "\n")

        if self.pattern == "IP_C_net" or self.pattern == "All":
            self.result.append("\nC-net Scan:\n")
            CScan = C_Scanner(self.url, 1)
            if CScan.threading():
                for i in CScan.result:
                    self.result.append(i + "\n")

        self.result = ''.join(self.result)

    def test(self):
        try:
            WFinger = WebFinger("hed9eh0g.top:80", 1)
            if WFinger.threading():
                self.result = []
                self.result.append("[+] " + WFinger.host + " use:")
                result = ""
                for j in WFinger.result:
                    result += j + "  "
                self.result.append("[+] fofa_banner: " + result)

            return self.result
        except Exception as e:
            raise (e)
